package com.chess.engine.player;
import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.Move;
import com.chess.engine.pieces.Piece;
import com.chess.engine.pieces.king;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
public abstract class player {
    protected final Board board;
    protected final king playerKing;
    protected final Collection<Move> legalMoves;
    private final boolean isInCheck;
    player(
            final Board board,
            final Collection<Move> legalMoves,
            final Collection<Move> opponentsMoves) {
        this.board = board;
        this.playerKing = establishKing();
        this.legalMoves =ImmutableList.copyOf(Iterables.concat( legalMoves,calculateKingCastles(legalMoves,opponentsMoves)));
        this.isInCheck = !player.calculateAttackOnTile(this.playerKing.getPiecePostion(), opponentsMoves).isEmpty();
    }
    public king getPlayerKing(){
        return this.playerKing;
    }
    public Collection<Move>getLegalMoves(){
        return this.legalMoves;
    }
    protected static Collection<Move> calculateAttackOnTile(int piecePostion, Collection<Move> moves) {
        final List<Move> attackMoves = new ArrayList<>();
        for (final Move move : moves){
            if(piecePostion == move.getDestinationCoordinate()){
                attackMoves.add(move);
            }
        }
        return ImmutableList.copyOf(attackMoves);
    }
    private king establishKing() {
        for (final Piece piece : getActivePieces()) {
            if (piece.getPieceType().isKing()) {
                return (king) piece;
            }
        }
        throw new  RuntimeException("the board is not valid! sorry");
    }
    public boolean isMoveLegal(final Move move){
       return this.legalMoves.contains(move);
    }
    public boolean isInCheck(){
        return this.isInCheck;
    }
    public boolean isInCheckMate(){
        return this.isInCheck && !hasEscapeMoves();
    }
    public boolean isInStaleMate(){
        return this.isInCheck && !hasEscapeMoves();
    }
    protected  boolean hasEscapeMoves(){
        for (final Move move: this.legalMoves){
            final MoveTransition transition = makeMove(move);
            if (transition.getMoveStatus().isDone()){
                return true;
            }
        }
        return false;
    }
    public boolean isCastled(){
        return false;
    }
    public MoveTransition makeMove(final Move move){
        if (!isMoveLegal(move)){
            return new MoveTransition(this.board,move,MoveStatus.ILLEGAL_MOVE);
        }
        final Board transitionBoard= move.execute();
        final Collection<Move> kingattacks = player.calculateAttackOnTile(transitionBoard.currentPlayer().getOpponent().getPlayerKing().getPiecePostion(),
                transitionBoard.currentPlayer().getLegalMoves());
        if (!kingattacks.isEmpty()){
            return new MoveTransition(this.board,move,MoveStatus.LEAVES_PLAYER_IN_CHECK);
        }
        return new MoveTransition(transitionBoard,move,MoveStatus.DONE);
    }
         public abstract Collection<Piece> getActivePieces ();
    public abstract Alliance getAllince();
    public abstract player getOpponent();
    protected abstract Collection<Move>calculateKingCastles(Collection<Move> playerLegals, Collection<Move>opponentsLegals);
    }
