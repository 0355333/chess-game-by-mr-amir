package com.chess.engine.pieces;
import com.chess.engine.Alliance;
import com.chess.engine.board.Board;
import com.chess.engine.board.BoardUtils;
import com.chess.engine.board.Move;
import com.chess.engine.board.Tile;
import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import static com.chess.engine.board.Move.*;
public class king extends Piece{
    private final static int[] CANDIDATE_MOVE_COORDINATE= {-9,-8,-7,-1,7,8,9};
    public king( final Alliance pieceAlliance,final int piecePostion) {
        super(PieceType.KING,piecePostion, pieceAlliance);
    }
    @Override
    public Collection<Move> calculateLegalMoves(Board board) {
    final List<Move> legalMoves = new ArrayList<>();
    for(final int currentCandidateOffset : CANDIDATE_MOVE_COORDINATE){
       final int candidateDestinationCoordinates = this.piecePostion + currentCandidateOffset;
       if (isFirstColumnExclusion(this.piecePostion,currentCandidateOffset)||
               isEighthColumnExclusion(this.piecePostion,currentCandidateOffset)){
           continue;
       }
       if (BoardUtils.isValidTileCoordinate(candidateDestinationCoordinates)){
           final Tile candidateDestinationTile = board.getTile(candidateDestinationCoordinates);
           if (!candidateDestinationTile.isTileOccupied()) {
               legalMoves.add(new MajorMove(board, this, candidateDestinationCoordinates));
           } else {
               final Piece pieceAtDestination = candidateDestinationTile.getPiece();
               final Alliance pieceAllience = pieceAtDestination.getPieceAlliance();
               if (this.pieceAlliance != pieceAllience) {
                   legalMoves.add(new AttackMove(board, this ,candidateDestinationCoordinates, pieceAtDestination));
               }
           }
       }
    }
        return ImmutableList.copyOf(legalMoves);
    }
    @Override
    public king movePiece(final Move move) {
        return new king(move.getMovedPiece().getPieceAlliance(),move.getDestinationCoordinate()) ;
    }
    @Override
    public String toString() {
        return PieceType.KING.toString();
    }
    private static boolean isFirstColumnExclusion(final int currentPostion, final int candidateOffset) {
        return BoardUtils.FIRST_COLUMN[currentPostion] && (candidateOffset == -9 || candidateOffset == -1|| candidateOffset == 7 );
    }
    private static boolean isEighthColumnExclusion(final int currentPostion,final int candidateOffset){
        return BoardUtils.EIGHTH_COLUMN[currentPostion]&& (candidateOffset == -7||candidateOffset==1 ||
                candidateOffset == 9);
    }
}
