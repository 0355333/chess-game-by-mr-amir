package com.chess.engine.board;
import com.chess.engine.Alliance;
import com.chess.engine.pieces.*;
import com.chess.engine.player.BlackPlayer;
import com.chess.engine.player.WhitePlayer;
import com.chess.engine.player.player;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import java.util.*;

    public class Board {
        private final List<Tile> gameBoard;
    private final Collection<Piece>whitePieces;
    private final Collection<Piece>blackPieces;

    private final WhitePlayer whitePlayer;
    private final BlackPlayer blackPlayer;
    private final player currentPlayer;

    private Board(final Builder builder) {
        this.gameBoard = createGameBoard(builder);
        this.whitePieces = calculateActivePieces(this.gameBoard,Alliance.WHITE);
        this.blackPieces = calculateActivePieces(this.gameBoard,Alliance.BLACK);


        final Collection<Move> whiteStandardLegalMoves = calculateLegalMoves(this.whitePieces);
        final Collection<Move> blackStandardLegalMoves= calculateLegalMoves(this.blackPieces);

        this.whitePlayer = new WhitePlayer(this, whiteStandardLegalMoves, blackStandardLegalMoves);
        this.blackPlayer = new BlackPlayer(this, whiteStandardLegalMoves, blackStandardLegalMoves);
        this.currentPlayer = builder.nextMoveMaker.choosePlayer(this.whitePlayer,this.blackPlayer);
    }
   @Override
   public String toString(){
        final StringBuilder builder= new StringBuilder();
        for (int i=0;i<BoardUtils.NUM_TILES;i++){
            final String tileText = this.gameBoard.get(i).toString();
            builder.append(String.format("%3s",tileText));
            if ((i+1) % BoardUtils.NUM_TILES_PER_ROW == 0){
                builder.append("\n");
            }
        }
        return builder.toString();
   }
    public player whitePlayer(){
        return this.whitePlayer;
   }
    public player blackPlayer() {
        return this.blackPlayer;
    }
    public player currentPlayer(){
        return this.currentPlayer;
    }
    public Collection<Piece> getBlackPieces(){
        return this.blackPieces;
   }
    public Collection<Piece> getWhitePieces() {
        return this.whitePieces;
    }
    private static String prettyPrint(final Tile tile) {
        return tile.toString();
    }
    private Collection<Move> calculateLegalMoves(final Collection<Piece> pieces) {
   final List<Move> legalMoves = new ArrayList<>();
   for (final Piece piece: pieces){
       legalMoves.addAll(piece.calculateLegalMoves(this));
   }
    return ImmutableList.copyOf(legalMoves);
    }
    private static Collection<Piece> calculateActivePieces(final List<Tile> gameBoard,
                                                           final Alliance alliance) {
        final List<Piece>activePieces = new ArrayList<>();
        for (final Tile tile : gameBoard){
            if (tile.isTileOccupied()){
                final Piece piece=tile.getPiece();
                if (piece.getPieceAlliance()== alliance){
                    activePieces.add(piece);
                }
            }
        }
            return ImmutableList.copyOf(activePieces);
    }
    public Tile getTile(final int tileCoordinate){
        return gameBoard.get(tileCoordinate);
    }
    private static List<Tile>createGameBoard(final Builder builder) {
        final Tile[] tiles = new Tile[BoardUtils.NUM_TILES];
        for (int i = 0; i < BoardUtils.NUM_TILES; i++) {
            tiles[i] = Tile.createTile(i, builder.boardConfig.get(i));
        }return ImmutableList.copyOf(tiles);
    }
    public static Board createStandardBoard(){
        final Builder builder = new Builder();
        // black layout
        builder.setPiece(new rook(Alliance.BLACK,0));
        builder.setPiece(new knight(Alliance.BLACK,1));
        builder.setPiece(new bishop(Alliance.BLACK,2));
        builder.setPiece(new Queen(Alliance.BLACK,3));
        builder.setPiece(new king(Alliance.BLACK,4));
        builder.setPiece(new bishop(Alliance.BLACK,5));
        builder.setPiece(new knight(Alliance.BLACK,6));
        builder.setPiece(new rook(Alliance.BLACK,7));
        builder.setPiece(new pawn(Alliance.BLACK,8));
        builder.setPiece(new pawn(Alliance.BLACK,9));
        builder.setPiece(new pawn(Alliance.BLACK,10));
        builder.setPiece(new pawn(Alliance.BLACK,11));
        builder.setPiece(new pawn(Alliance.BLACK,12));
        builder.setPiece(new pawn(Alliance.BLACK,13));
        builder.setPiece(new pawn(Alliance.BLACK,14));
        builder.setPiece(new pawn(Alliance.BLACK,15));
        //white layout
        builder.setPiece(new pawn(Alliance.WHITE,48));
        builder.setPiece(new pawn(Alliance.WHITE,49));
        builder.setPiece(new pawn(Alliance.WHITE,50));
        builder.setPiece(new pawn(Alliance.WHITE,51));
        builder.setPiece(new pawn(Alliance.WHITE,52));
        builder.setPiece(new pawn(Alliance.WHITE,53));
        builder.setPiece(new pawn(Alliance.WHITE,54));
        builder.setPiece(new pawn(Alliance.WHITE,55));
        builder.setPiece(new rook(Alliance.WHITE,56));
        builder.setPiece(new knight(Alliance.WHITE,57));
        builder.setPiece(new bishop(Alliance.WHITE,58));
        builder.setPiece(new Queen(Alliance.WHITE,59));
        builder.setPiece(new king(Alliance.WHITE,60));
        builder.setPiece(new bishop(Alliance.WHITE,61));
        builder.setPiece(new knight(Alliance.WHITE,62));
        builder.setPiece(new rook (Alliance.WHITE,63));
        //white to move
        builder.setMoveMaker(Alliance.WHITE);
        return builder.build();
    }
    public Iterable<Move> getAllLegalMoves() {
        return Iterables.unmodifiableIterable(Iterables.concat(this.whitePlayer.getLegalMoves(),this.blackPlayer.getLegalMoves()));
    }
    public static  class Builder{
       Map<Integer, Piece> boardConfig;
       Alliance nextMoveMaker;
       pawn enPassantPawn;
       public Builder(){
           this.boardConfig = new HashMap<>();
       }
       public Builder setPiece(final Piece piece){
           this.boardConfig.put(piece.getPiecePostion(), piece);
           return this;
       }
public Builder setMoveMaker (final Alliance alliance){
           this.nextMoveMaker = alliance;
           return this;
       }
        public Board build() {
            return new Board(this);
        }
        public void setEnPassantPawn(pawn enPassantPawn) {
           this.enPassantPawn = enPassantPawn;
        }
    }
}