package com.chess;
import com.chess.engine.board.Board;
import com.chess.gui.Table;

import static com.chess.engine.board.Board.createStandardBoard;

public class ZChess {
    public static void main(String[]args){
        Board board = createStandardBoard();
        System.out.println(board);
        Table table = new Table();
    }

}
