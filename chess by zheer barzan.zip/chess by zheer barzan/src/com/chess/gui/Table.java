package com.chess.gui;
import javax.swing.*;
import java.awt.*;

public class Table {
    private final JFrame gameFrame;
    private static Dimension OUTER_FRAME_DIMENSION = new Dimension(1500,1500);
    public Table(){
        this.gameFrame =new JFrame("zheer's Frame");
        this.gameFrame.setSize(OUTER_FRAME_DIMENSION);
        this.gameFrame.setVisible(true);


    }
}
